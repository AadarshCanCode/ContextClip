# ContextClip Agent Package

- `ContextClip_Coding_Agent_Spec_v4_AGENT.md` — agent-readable Markdown specification.
- `ContextClip_Coding_Agent_Spec_v4.docx` — original source document.
- `assets/image_1.jpeg` — embedded UI reference from page 1.

## Tables
All source DOCX tables are converted to Markdown tables in the agent-readable specification, so coding agents can parse their rows/columns without needing Word rendering.

## Images
The DOCX contains one embedded image. It is extracted and linked from the Markdown. The architecture diagram on page 8 is represented in the rendered/source document rather than as a separate embedded media file.
